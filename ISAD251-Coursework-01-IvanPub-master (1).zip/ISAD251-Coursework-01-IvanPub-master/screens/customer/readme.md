this is the screen of customer
