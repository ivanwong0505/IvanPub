This is the screen of admin
